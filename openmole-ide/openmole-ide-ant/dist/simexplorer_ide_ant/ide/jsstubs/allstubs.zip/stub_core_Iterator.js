var Iterator = { // COMPAT=FF2|FF3|OPERA|SAFARI3|KONQ
  // This is just a stub for a builtin native JavaScript object.
/** Return the next item from the iterator
*/
next: function() { // COMPAT=FF2|FF3|OPERA|SAFARI3|KONQ
  // This is just a stub for a builtin native JavaScript object.
},
};
function Iterator(collection) {}; // COMPAT=FF2|FF3|OPERA|SAFARI3|KONQ
function Iterator(collection,keysOnly) {}; // COMPAT=FF2|FF3|OPERA|SAFARI3|KONQ

