var DocumentView = {
  // This is just a stub for a builtin native JavaScript object.
/**
 * The default AbstractView
 * for this Document, or null if none
 * available.
 * @type AbstractView
 */
defaultView: undefined,
};

