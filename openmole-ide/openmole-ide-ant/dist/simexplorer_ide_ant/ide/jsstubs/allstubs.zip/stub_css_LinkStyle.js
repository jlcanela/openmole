var LinkStyle = {
  // This is just a stub for a builtin native JavaScript object.
/**
 * The style sheet.
 * @type StyleSheet
 */
sheet: undefined,
};

