var CSSFontFaceRule = Object.extend(new CSSRule(), {
  // This is just a stub for a builtin native JavaScript object.
/**
 * The style attribute.
 * @type CSSStyleDeclaration
 */
style: undefined,
});

